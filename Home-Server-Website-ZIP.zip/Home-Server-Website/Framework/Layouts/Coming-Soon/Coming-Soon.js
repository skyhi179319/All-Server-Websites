$(document).ready(function(){
	$("#ImportComingSoon").load("http://192.168.0.118/Home-Server-Website/Framework/Layouts/Coming-Soon/Coming-Soon.html");
}); 