$(document).ready(function(){
	$("#ImportNav").load("http://192.168.0.118/Home-Server-Website/Framework/Layouts/Navbar.html");
	$("#ImportHeader").load("http://192.168.0.118/Home-Server-Website/Framework/Layouts/Header.html");
});