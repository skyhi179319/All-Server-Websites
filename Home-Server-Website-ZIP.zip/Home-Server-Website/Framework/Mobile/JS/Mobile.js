$(document).ready(function(){
    // Global Styles
    function GlobalStyles(){
        var CurrentURL = window.location.href;
		// Page Functions
		function AboutPage(){
			$(document).ready(function(){
				$("#ImportAPI").remove();
			}); 
		}
		function AppPage(){
			$(document).ready(function(){
				$("#ImportAPI").remove();
			}); 
		}
		// Check URLS
        if(CurrentURL == "http://192.168.0.118/Home-Server-Website/Pages/About.html"){
	        AboutPage();
        }
        if(CurrentURL == "http://192.168.0.118/Home-Server-Website/Pages/App.html"){
	        AppPage();
        }
	}
	// Add Content
	function AddContent(){
		var CurrentURL = window.location.href;
		// Page Functions
		function HomePage(){
			$(document).ready(function(){
				$("#MobileContent").load("http://192.168.0.118/Home-Server-Website/Framework/Mobile/Home/Home.html")
			}); 
		}
		// Check URLS
        if(CurrentURL == "http://192.168.0.118/Home-Server-Website/Home.html"){
	        HomePage();
        }
	}
    if(window.matchMedia("(max-width: 767px)").matches){
        // The viewport is less than 768 pixels wide
        GlobalStyles();
		AddContent();
    }
});