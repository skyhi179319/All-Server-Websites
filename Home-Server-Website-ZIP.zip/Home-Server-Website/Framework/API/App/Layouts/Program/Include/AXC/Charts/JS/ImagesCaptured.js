var data = [
  {
    x: ['3/21 - 3/22'],
    y: [27],
    type: 'bar'
  }
];

Plotly.newPlot('ImagesCapturedChart', data);