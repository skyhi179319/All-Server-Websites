$( function() {
    $( "#accordion" ).accordion();
});