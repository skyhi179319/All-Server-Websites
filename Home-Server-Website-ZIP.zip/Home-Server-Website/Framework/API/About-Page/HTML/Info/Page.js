$( function() {
    $( "#dialog" ).dialog();
} );