$( function() {
    $( "#dialog" ).dialog();
} );
$("#ImportModalText").load("http://192.168.0.118/Home-Server-Website/Framework/API/Improvements/Details.html");