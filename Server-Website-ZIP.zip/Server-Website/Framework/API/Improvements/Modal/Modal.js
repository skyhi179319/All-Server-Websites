$( function() {
    $( "#dialog" ).dialog();
} );
$("#ImportModalText").load("http://127.0.0.1/Server-Website/Framework/API/Improvements/Details.html");