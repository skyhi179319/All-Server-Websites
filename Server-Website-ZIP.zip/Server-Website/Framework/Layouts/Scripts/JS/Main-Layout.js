$(document).ready(function(){
	$("#ImportNav").load("http://127.0.0.1/Server-Website/Framework/Layouts/Navbar.html");
	$("#ImportHeader").load("http://127.0.0.1/Server-Website/Framework/Layouts/Header.html");
});