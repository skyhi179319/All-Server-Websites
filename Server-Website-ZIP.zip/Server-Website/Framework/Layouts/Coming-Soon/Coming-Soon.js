$(document).ready(function(){
	$("#ImportComingSoon").load("http://127.0.0.1/Server-Website/Framework/Layouts/Coming-Soon/Coming-Soon.html");
}); 